-- =====================================================================
--  Ride a Horse - Server
--  Relays mount/dismount events so every nearby client sees the rider
-- =====================================================================

RegisterNetEvent('rideAHorse:mount', function(horseNetId)
    local src = source
    if type(horseNetId) ~= 'number' then return end
    -- Broadcast to all clients (including sender; sender's handler skips itself)
    TriggerClientEvent('rideAHorse:remoteMount', -1, src, horseNetId)
end)

RegisterNetEvent('rideAHorse:dismount', function()
    local src = source
    TriggerClientEvent('rideAHorse:remoteDismount', -1, src)
end)

-- When a player drops, tell everyone to clean up if they were mounted
AddEventHandler('playerDropped', function()
    local src = source
    TriggerClientEvent('rideAHorse:remoteDismount', -1, src)
end)
