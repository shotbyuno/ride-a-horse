-- =====================================================================
--  Ride a Horse for FiveM
--  Original concept ported from gta5-mods.com / IllidanS4
--  Modernized for current FiveM (cerulean, Lua 5.4)
--  Author: shotbyuno
-- =====================================================================

-- ---------------------------------------------------------------------
-- Configuration
-- ---------------------------------------------------------------------
local Config = {
    -- NOTE: Model stays as `a_c_deer` because the deer skeleton is
    -- reskinned with a horse texture/model swap. Do NOT change this hash.
    HorseModel        = `a_c_deer`,
    RideControl       = 51,            -- Keyboard: E / Controller: dpad right (mount / dismount)
    SprintControls    = { 21, 16 },    -- Keyboard: LSHIFT (21) / Controller: Xbox A (16)
    Speeds = {
        Walk = 6.0,                    -- ~trot
        Run  = 14.0,                   -- ~gallop
    },
    -- Range fed to TaskGoStraightToCoord; bigger range = the ped commits
    -- to the target longer, which keeps it from constantly stopping.
    MoveRange = {
        Walk = 8.0,
        Run  = 18.0,
    },
    InteractionRadius = 3.0,
    ShowMarker        = false,
    HorseInvincible   = true,
    HorseCanRagdoll   = false,
    AnimDict          = 'rcmjosh2',
    AnimName          = 'josh_sitting_loop',
    SeatBoneIndex     = 24816,         -- spine bone on the deer skeleton
}

-- ---------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------
local Horse        = { Handle = nil }
local RemoteRiders = {}   -- [serverId] = horseNetId  (peers we've attached)

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------

--- Check if any specified control input is currently pressed
local function IsAnyControlPressed(padIndex, controlsTable)
    for i = 1, #controlsTable do
        if IsControlPressed(padIndex, controlsTable[i]) then
            return true
        end
    end
    return false
end

--- Display floating 3D text in the world
local function DrawText3D(coords, text)
    local onScreen, _x, _y = SetDrawOrigin(coords.x, coords.y, coords.z + 0.8, 0)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
        ClearDrawOrigin()
    end
end

--- Display a help notification banner in the top left
local function DisplayHelpText(text)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentString(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

--- Get peds within `radius` of `coords`, excluding players.
local function GetNearbyPeds(coords, radius)
    local list = {}
    for _, ped in ipairs(GetGamePool('CPed')) do
        if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
            if #(coords - GetEntityCoords(ped)) <= radius then
                list[#list + 1] = ped
            end
        end
    end
    return list
end

--- Compute coords offset from an entity by distance/heading offset (degrees).
local function GetCoordsInfrontOfEntityWithDistance(entity, distance, headingOffset)
    local pos = GetEntityCoords(entity)
    local h   = (GetEntityHeading(entity) + (headingOffset or 0.0)) * math.pi / 180.0
    return vector3(pos.x + distance * math.sin(-h),
                   pos.y + distance * math.cos(-h),
                   pos.z)
end

--- Get the ground Z at a given x/y/z; falls back to the input z if not found.
local function GetGroundZ(x, y, z)
    local found, gz = GetGroundZFor_3dCoord(x + 0.0, y + 0.0, z + 0.0, false)
    if found then return gz end
    return z
end

--- Request a model with timeout.
local function LoadModel(model)
    if HasModelLoaded(model) then return true end
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        return false
    end
    RequestModel(model)
    local deadline = GetGameTimer() + 5000
    while not HasModelLoaded(model) do
        if GetGameTimer() > deadline then return false end
        Wait(0)
    end
    return true
end

--- Request an animation dictionary with timeout.
local function LoadAnimDict(dict)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + 5000
    while not HasAnimDictLoaded(dict) do
        if GetGameTimer() > deadline then return false end
        Wait(0)
    end
    return true
end

--- Fully detach a ped from whatever it's attached to.
local function DetachPed(ped)
    if IsEntityAttached(ped) then
        DetachEntity(ped, true, false)
    end
    ClearPedTasksImmediately(ped)
end

-- ---------------------------------------------------------------------
-- Horse logic (local)
-- ---------------------------------------------------------------------

function Horse.Create()
    if Horse.Handle and DoesEntityExist(Horse.Handle) then
        return -- already have one
    end

    if not LoadModel(Config.HorseModel) then
        print('[RideAHorse] Failed to load horse model')
        return
    end

    local ped     = PlayerPedId()
    local spawnPos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 2.0, 0.0)
    local heading = GetEntityHeading(ped)
    local groundZ = GetGroundZ(spawnPos.x, spawnPos.y, spawnPos.z)

    Horse.Handle = CreatePed(28, Config.HorseModel,
        spawnPos.x, spawnPos.y, groundZ, heading,
        true,   -- networked  (so other players' clients can see it)
        true)   -- script-host

    SetModelAsNoLongerNeeded(Config.HorseModel)

    if not DoesEntityExist(Horse.Handle) then
        Horse.Handle = nil
        return
    end

    SetPedCanRagdoll(Horse.Handle, Config.HorseCanRagdoll)
    SetEntityInvincible(Horse.Handle, Config.HorseInvincible)
    SetEntityAsMissionEntity(Horse.Handle, true, true)

    -- Make sure ownership is reported to the network so other clients
    -- can resolve the entity from its network ID.
    if NetworkGetEntityIsNetworked(Horse.Handle) then
        SetNetworkIdCanMigrate(NetworkGetNetworkIdFromEntity(Horse.Handle), true)
    end
end

function Horse.Destroy()
    DetachPed(PlayerPedId())

    -- Tell other clients we're not riding anymore
    TriggerServerEvent('rideAHorse:dismount')

    if Horse.Handle and DoesEntityExist(Horse.Handle) then
        SetEntityAsMissionEntity(Horse.Handle, true, true)
        DeleteEntity(Horse.Handle)
    end
    Horse.Handle = nil
end

function Horse.Mount()
    local ped = PlayerPedId()

    if not LoadAnimDict(Config.AnimDict) then
        print('[RideAHorse] Failed to load animation dict')
        return
    end

    FreezeEntityPosition(Horse.Handle, true)
    FreezeEntityPosition(ped, true)

    local horsePos = GetEntityCoords(Horse.Handle)
    SetEntityCoords(ped, horsePos.x, horsePos.y, horsePos.z, false, false, false, false)

    AttachEntityToEntity(ped, Horse.Handle,
        GetPedBoneIndex(Horse.Handle, Config.SeatBoneIndex),
        -0.3, 0.0, 0.3,
         0.0, 0.0, 90.0,
        false, false, false, true, 2, true)

    TaskPlayAnim(ped, Config.AnimDict, Config.AnimName,
        8.0, 1.0, -1, 2, 1.0,
        false, false, false)

    FreezeEntityPosition(Horse.Handle, false)
    FreezeEntityPosition(ped, false)

    -- Announce to other clients so they can attach us visually on their end
    if NetworkGetEntityIsNetworked(Horse.Handle) then
        local horseNetId = NetworkGetNetworkIdFromEntity(Horse.Handle)
        TriggerServerEvent('rideAHorse:mount', horseNetId)
    end
end

function Horse.Dismount()
    local ped      = PlayerPedId()
    local attached = GetEntityAttachedTo(ped)

    if attached == 0 or not DoesEntityExist(attached) then
        DetachPed(ped)
        TriggerServerEvent('rideAHorse:dismount')
        return
    end

    local sideCoords  = GetCoordsInfrontOfEntityWithDistance(attached, 1.0, 90.0)
    local sideHeading = GetEntityHeading(attached)
    local groundZ     = GetGroundZ(sideCoords.x, sideCoords.y, sideCoords.z)

    DetachPed(ped)

    SetEntityCoords(ped, sideCoords.x, sideCoords.y, groundZ, false, false, false, false)
    SetEntityHeading(ped, sideHeading)

    TriggerServerEvent('rideAHorse:dismount')
end

--- Toggle mount/dismount based on current state.
function Horse.ToggleRide()
    local ped = PlayerPedId()

    if IsPedSittingInAnyVehicle(ped) or IsPedGettingIntoAVehicle(ped) then
        return
    end
    if IsPedDeadOrDying(ped, true) then
        return
    end

    local attached = GetEntityAttachedTo(ped)

    -- Already mounted? Dismount.
    if IsEntityAttached(ped)
       and attached ~= 0
       and DoesEntityExist(attached)
       and GetEntityModel(attached) == Config.HorseModel then
        Horse.Dismount()
        return
    end

    -- Otherwise look for a nearby horse to mount.
    local pedPos = GetEntityCoords(ped)

    -- Priority check: Is our spawned horse handle nearby?
    if Horse.Handle and DoesEntityExist(Horse.Handle) then
        if #(pedPos - GetEntityCoords(Horse.Handle)) <= Config.InteractionRadius then
            Horse.Mount()
            return
        end
    end

    -- Fallback check: Look for any nearby horse-model ped
    for _, nearby in ipairs(GetNearbyPeds(pedPos, Config.InteractionRadius)) do
        if GetEntityModel(nearby) == Config.HorseModel then
            Horse.Handle = nearby
            Horse.Mount()
            return
        end
    end
end

-- ---------------------------------------------------------------------
-- Remote rider sync (so OTHER players see us mounted, and we see them)
-- ---------------------------------------------------------------------

--- Apply the visual mount on a remote player ped.
local function ApplyRemoteMount(targetPed, horseEntity)
    -- Make sure the anim dict is loaded on this client too
    if not HasAnimDictLoaded(Config.AnimDict) then
        RequestAnimDict(Config.AnimDict)
        local deadline = GetGameTimer() + 3000
        while not HasAnimDictLoaded(Config.AnimDict) and GetGameTimer() < deadline do
            Wait(50)
        end
    end

    if IsEntityAttached(targetPed) then
        DetachEntity(targetPed, true, false)
    end

    AttachEntityToEntity(targetPed, horseEntity,
        GetPedBoneIndex(horseEntity, Config.SeatBoneIndex),
        -0.3, 0.0, 0.3,
         0.0, 0.0, 90.0,
        false, false, false, true, 2, true)

    TaskPlayAnim(targetPed, Config.AnimDict, Config.AnimName,
        8.0, 1.0, -1, 2, 1.0,
        false, false, false)
end

RegisterNetEvent('rideAHorse:remoteMount', function(playerSrc, horseNetId)
    -- Skip our own echo - we already attached locally
    if playerSrc == GetPlayerServerId(PlayerId()) then
        RemoteRiders[playerSrc] = horseNetId
        return
    end

    local playerId = GetPlayerFromServerId(playerSrc)
    if playerId == -1 then return end

    RemoteRiders[playerSrc] = horseNetId

    -- The horse entity may not be in scope yet on this client; wait for it.
    CreateThread(function()
        local deadline = GetGameTimer() + 8000
        while GetGameTimer() < deadline do
            -- The rider may have dismounted while we were waiting
            if RemoteRiders[playerSrc] ~= horseNetId then return end

            local targetPed = GetPlayerPed(playerId)
            local horseEntity = NetworkDoesNetworkIdExist(horseNetId)
                                and NetworkGetEntityFromNetworkId(horseNetId) or 0

            if DoesEntityExist(targetPed) and DoesEntityExist(horseEntity) then
                ApplyRemoteMount(targetPed, horseEntity)
                return
            end
            Wait(150)
        end
    end)
end)

RegisterNetEvent('rideAHorse:remoteDismount', function(playerSrc)
    RemoteRiders[playerSrc] = nil

    if playerSrc == GetPlayerServerId(PlayerId()) then
        return -- our own dismount was already handled locally
    end

    local playerId = GetPlayerFromServerId(playerSrc)
    if playerId == -1 then return end

    local targetPed = GetPlayerPed(playerId)
    if not DoesEntityExist(targetPed) then return end

    if IsEntityAttached(targetPed) then
        DetachEntity(targetPed, true, false)
    end
    ClearPedTasks(targetPed)
end)

-- ---------------------------------------------------------------------
-- Command Handling
-- ---------------------------------------------------------------------

RegisterCommand('horse', function()
    if Horse.Handle and DoesEntityExist(Horse.Handle) then
        Horse.Destroy()
    else
        Horse.Create()
    end
end, false)

-- ---------------------------------------------------------------------
-- Main loop
-- ---------------------------------------------------------------------

CreateThread(function()
    LoadAnimDict(Config.AnimDict)

    while true do
        Wait(0)

        local ped      = PlayerPedId()
        local attached = GetEntityAttachedTo(ped)
        local pedPos   = GetEntityCoords(ped)

        -- Are we currently riding our horse model?
        local isMounted = false
        if attached ~= 0
           and DoesEntityExist(attached)
           and GetEntityModel(attached) == Config.HorseModel then
            isMounted = true
        end

        -- Contextual prompts & interaction check
        if not isMounted then
            local promptShown = false

            -- 1. Check our explicitly handled script horse first
            if Horse.Handle and DoesEntityExist(Horse.Handle) then
                local horseCoords = GetEntityCoords(Horse.Handle)
                if #(pedPos - horseCoords) <= Config.InteractionRadius then
                    DrawText3D(horseCoords, "Press ~g~E~w~ to ride")
                    promptShown = true
                end
            end

            -- 2. Fallback to general area search
            if not promptShown then
                local nearbyPeds = GetNearbyPeds(pedPos, Config.InteractionRadius)
                for i = 1, #nearbyPeds do
                    local nearby = nearbyPeds[i]
                    if GetEntityModel(nearby) == Config.HorseModel then
                        DrawText3D(GetEntityCoords(nearby), "Press ~g~E~w~ to ride")
                        break
                    end
                end
            end
        else
            DisplayHelpText("Press ~INPUT_CONTEXT~ to dismount.")
        end

        -- Mount / dismount via E key (or controller equivalent)
        if IsControlJustReleased(0, Config.RideControl) then
            Horse.ToggleRide()
        end

        -- If our horse was deleted by the engine, clear our handle.
        if Horse.Handle and not DoesEntityExist(Horse.Handle) then
            Horse.Handle = nil
            DetachPed(ped)
        end

        -- Riding controls
        if isMounted
           and Horse.Handle
           and not IsPedSittingInAnyVehicle(ped)
           and not IsPedGettingIntoAVehicle(ped)
           and not IsPedDeadOrDying(ped, true) then

            -- Ensure we have control of the horse so movement actually happens
            -- (otherwise on remote-owned entities our task calls get ignored).
            if not NetworkHasControlOfEntity(Horse.Handle) then
                NetworkRequestControlOfEntity(Horse.Handle)
            end

            local lx = GetControlNormal(0, 218)  -- SCRIPT_LEFT_AXIS_X
            local ly = GetControlNormal(0, 219)  -- SCRIPT_LEFT_AXIS_Y
            local speed = Config.Speeds.Walk
            local range = Config.MoveRange.Walk

            -- Sprint while LSHIFT or controller A is held
            if IsAnyControlPressed(0, Config.SprintControls) then
                speed = Config.Speeds.Run
                range = Config.MoveRange.Run
            end

            local target = GetOffsetFromEntityInWorldCoords(Horse.Handle,
                lx * range, ly * -1.0 * range, 0.0)

            TaskLookAtCoord(Horse.Handle, target.x, target.y, target.z, 1000, 0, 2)
            TaskGoStraightToCoord(Horse.Handle, target.x, target.y, target.z,
                speed, 20000, 0.0, 0.5)

            -- Force the deer's run-style movement so the gait matches the high speed
            SetPedDesiredHeading(Horse.Handle, GetEntityHeading(Horse.Handle))
            SetRunSprintMultiplierForPlayer(PlayerId(), 1.49)

            if Config.ShowMarker then
                DrawMarker(6, target.x, target.y, target.z,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    1.0, 1.0, 1.0,
                    255, 255, 255, 255,
                    false, false, 2, false, nil, nil, false)
            end
        end

        -- Auto-detach if player dies while attached
        if IsEntityAttached(ped) and IsPedDeadOrDying(ped, true) then
            DetachPed(ped)
            TriggerServerEvent('rideAHorse:dismount')
        end
    end
end)

-- ---------------------------------------------------------------------
-- Cleanup on resource stop
-- ---------------------------------------------------------------------
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    DetachPed(PlayerPedId())

    if Horse.Handle and DoesEntityExist(Horse.Handle) then
        SetEntityAsMissionEntity(Horse.Handle, true, true)
        DeleteEntity(Horse.Handle)
    end
    Horse.Handle = nil
    RemoteRiders = {}
end)
