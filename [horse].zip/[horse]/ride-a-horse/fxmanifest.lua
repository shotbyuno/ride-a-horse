fx_version 'cerulean'
game 'gta5'

author 'shotbyuno'
description 'Ride a horse in FiveM'
version '2.1.0'

lua54 'yes'

client_script 'client.lua'
server_script 'server.lua'
